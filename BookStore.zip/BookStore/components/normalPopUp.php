<!-- is just like popup forms forms -->
<!-- 
    1. change password pop up form
    2. popup for confirmation eg . do you want to delete your account and sometihng like this

-->
<?php
function AddCartSucessMsg()
{
    echo '';
}
?>
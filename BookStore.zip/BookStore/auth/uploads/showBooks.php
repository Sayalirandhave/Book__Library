<?php
include '../../connect.php';
include '../../components/warning.php';
if (isset($_POST['upload-book'])) {
    $book_Name = $_POST['book-name'];
    $lang = $_POST['lang'];
    $price = floatval($_POST['price']);
    $edition = $_POST['edition'];
    $stock = $_POST['stock'];
    $genere = $_POST['genere'];
    $publication = $_POST['pub-date'];
    $status = "Available";
    $auth_Id = 1;

    $book_Image = $_FILES['image'];

    $img_Name = $book_Image['name'];
    $extensions = array('jpg', 'jpeg', 'png', 'webp');
    $split_img = explode('.', $img_Name);
    $ext = strtolower($split_img[1]);

    if (count($split_img) <= 2) {
        if (in_array($ext, $extensions)) {
            // sql query
            $book_Image['name'] = $book_Name;
            $book_tmp = $book_Image['tmp_name'];

            $upload_image = '../../assets/bookImages/' . $book_Image['name'] . "." . $ext;
            $actual_upload_image_in_DB = 'assets/bookImages/' . $book_Image['name'] . "." . $ext;

            move_uploaded_file($book_tmp, $upload_image);

            // $sql = "INSERT INTO `bookstore`( `title`, `language`, `publication_date`, `author_id`, `price`, `image`, `edition`, `status`, `stock`, `genre`, `time`) VALUES ('$book_Name','1','$publication','1','$price','$actual_upload_image_in_DB','$edition','available','$stock','$genere',CURRENT_TIME())";
            $sql = "INSERT INTO books (`title`,`language`,`publication_date`,`author_id`,`price`,`image`,`edition`,`status`,`stock`,`genre`,`time`) VALUES('$book_Name','$lang','$publication',$auth_Id,$price,'$actual_upload_image_in_DB',$edition,'$status',$stock,'$genere',CURRENT_TIME())";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                Warning("book Uploaded sucessfully", "flex");
            }

        } else
            Warning("Please select only images", "flex");
    } else {
        Warning("images more than two dots (..) are not allowed", "flex");
    }

}
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>show tables</title>
    <link rel= 'icon' href= 'data:,'>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>

<div class="grid min-h-screen w-full overflow-hidden ">
    <div class="flex flex-col">
      <header class="flex h-14 items-center gap-4 border-b bg-gray-100/40 px-6">
        <a class="lg:hidden" href="#" rel="ugc">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-6 w-6"><path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z"></path><path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9"></path><path d="M12 3v6"></path></svg>
          <span class="sr-only">Home</span>
        </a>
        <div class="w-full">
          <h1 class="font-semibold text-lg">All Books</h1>
        </div>
        <button class="inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground rounded-full border border-gray-200 w-8 h-8 dark:border-gray-800" type="button" id="radix-:Rdlafnnja:" aria-haspopup="menu" aria-expanded="false" data-state="closed">
          <img src="../assets/avtar/1Shubh.jpg" width="32" height="32" class="rounded-full" alt="Avatar" style="aspect-ratio:32/32;object-fit:cover">
          <span class="sr-only">Toggle user menu</span>
        </button>
      </header>
      <main class="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6 bg-white rounded-lg">
        <div class="border shadow-sm rounded-lg p-2">
          <div class="relative w-full overflow-auto">
            <table class="w-full caption-bottom text-sm">
              <thead class="[&amp;_tr]:border-b">
                <tr class="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                  <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 w-[100px]">Image</th>
                  <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 min-w-[150px]">Book Title</th>
                  <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 hidden md:table-cell">Language</th>
                <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 hidden md:table-cell">Price</th>
                <th class="h-12 px-4 align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 text-center">Description</th>
                <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 hidden sm:table-cell">Publication Date</th>
                <th class="h-12 px-4 align-middle font-medium text-muted-foreground [&amp;:has([role=checkbox])]:pr-0 text-right">Actions</th>
              </tr>
            </thead>
            <?php
              $sql = "SELECT * FROM books ORDER BY books.id DESC";
              $result = mysqli_query($conn,$sql);
              if(mysqli_num_rows($result)<1)
                echo "No Books Posted Yet";
              else{
                while($row = mysqli_fetch_assoc($result))
                {
                  $image = $row['image'];
                  $title = $row['title'];
                  $lang = $row['language'];
                  $desc = $row['description'];
                  $price = $row['price'];
                  $pub_date = $row['publication_date'];
                  echo '
                  <tbody class="[&amp;_tr:last-child]:border-0">
                    <tr class="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 font-medium"><img src="../'.$image.'" class="w-20 h-20 rounded-lg object-cover"/></td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0">'.$title.'</td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 hidden md:table-cell">'.$lang.'</td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 hidden md:table-cell">₹'.$price.'</td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 text-left">'.$desc.'</td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 hidden sm:table-cell">'.$pub_date.'</td>
                    <td class="p-4 align-middle [&amp;:has([role=checkbox])]:pr-0 text-right">
                    <button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground h-10 w-10" type="button" id="radix-:Rf3elafnnja:" aria-haspopup="menu" aria-expanded="false" data-state="closed">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg>
                      <span class="sr-only">Actions</span>
                    </button>
                    </td>
                    </tr>
                  </tbody>
                  ';
                }
              }

            ?>

            </table>
              </div>
            </div>
          </main>
        </div>
      </div>
</body>
</html>